set serveroutput on
set verify off
declare 
	curs SYS_REFCURSOR;
	curs1 SYS_REFCURSOR;
	curs2 SYS_REFCURSOR;
	curs3 SYS_REFCURSOR;
    theserial stock2.serial%TYPE;
    themodel stock2.model%TYPE;
	thename stock2.brand_name%TYPE;
	thetype stock2.types%TYPE;
	thequantity stock2.quantity%TYPE;
	thelocation stock2.location%TYPE;
	thecontact employee2.contact%TYPE := '&customer_contact';
	theempcon employee2.contact%type:='&employee_contact';
	--a stock2.types%TYPE :='Laptop';
	--t varchar2(10);
	v varchar(100):='&TYPE';
	r number :=0;
	con employee2.contact%TYPE;
	
begin 
--function find_prod calling
   if v='Laptop' then
      r :=1;
   --elsif v='PC' then
     --r :=2;
   else
    r:=3;
    DBMS_OUTPUT.PUT_LINE('Not Found' );
   end if;
   curs :=myPackage.find_prod(r); 
   
   LOOP
        FETCH curs INTO thename;
        EXIT WHEN curs%NOTFOUND;
        DBMS_OUTPUT.PUT_LINE(thename );
   END LOOP;
   CLOSE curs;

   
   
 --procedure available calling  
myPackage.available(curs1);
	 DBMS_OUTPUT.PUT_LINE('The available products are:');
	 	 DBMS_OUTPUT.PUT_LINE('Id'||'   '||'Name'||'    '||'Type'||'    '||'Quantity');	 	
	 	 
	LOOP
        FETCH curs1 INTO theserial,thename,thetype,thequantity;
        EXIT WHEN curs1%NOTFOUND;
        DBMS_OUTPUT.PUT_LINE(theserial||' '||thename||'   '|| thetype||' '||thequantity);
    END LOOP;
    CLOSE curs1;
    
   
      
--procedure find_employee call
myPackage.find_employee(thecontact,curs2);
	 DBMS_OUTPUT.PUT_LINE('THE EMPLOYEE INFORMATION:');
	LOOP
        FETCH curs2 INTO theserial,thename,thecontact;
        EXIT WHEN curs2%NOTFOUND;
        DBMS_OUTPUT.PUT_LINE(theserial||'  '||thename||'   '|| thecontact);
    END LOOP;
    CLOSE curs2;


--procedure find_emp_servings call 
myPackage.find_employee_servings(theempcon,curs3);
  DBMS_OUTPUT.PUT_LINE('Servings'||'   '||'ID');
	LOOP
        FETCH curs3 INTO theserial,thename;
        EXIT WHEN curs3%NOTFOUND;
        DBMS_OUTPUT.PUT_LINE(theserial||' '||thename);
    END LOOP;
    CLOSE curs3;



END;
/
commit;