clear screen;
--DROP TABLE employee2 CASCADE CONSTRAINTS;
--CREATE TABLE employee2(
  --  id int,
   -- name varchar(10),
    --contact varchar(20),
    --salary int,
    --location varchar(10),
    --PRIMARY KEY(id)); 
--commit;

set serveroutput on;
declare
	
	theid employee2.id%TYPE;
	thename employee2.name%TYPE;
	thecontact employee2.contact%TYPE;
	thesalary employee2.salary%TYPE;
	thelocation employee2.location%TYPE;
    
	cursor employee_cursor is
	select * from employee2 where location='Chittagong';
		

begin
	open employee_cursor;
	loop
		fetch employee_cursor into theid,thename,thecontact,thesalary,thelocation;
		
		exit when employee_cursor%notfound;
		end loop;
		insert into employee @site_link2 values(theid,thename,thecontact,thesalary,'Chittagong');
	close employee_cursor;
	
commit;	
end;
/