create or replace package body myPackage as 
	function find_prod(t in number)
	  return SYS_REFCURSOR
	   AS
	  c SYS_REFCURSOR;
	BEGIN
 
		if t=1 then
			open c for select brand_name from stock2 where types='Laptop' ;
		elsif t=2 then
			open c for select brand_name from stock2 where types='PC' ;
		else
			open c for select brand_name from stock2 where types='RAM' ;
		end if;	
	RETURN c;
	commit;	
	END find_prod;

 procedure available
	(c OUT SYS_REFCURSOR) 
	IS
	
begin 
	open c for select serial,brand_name,types,quantity from stock2 where quantity>0;
	
	
end available; 

procedure find_employee
	(con in varchar,cur OUT SYS_REFCURSOR) 
	IS
	
begin 
	
	open cur for select employee2.id,employee2.name,employee2.contact from employee2 join information2 on employee2.id=information2.employee_id where information2.cust_contact=con;
	
end find_employee; 

	
	
procedure find_employee_servings
	(emp_con in varchar,cur OUT SYS_REFCURSOR) 
	IS
	
begin 
	
	open cur for select COUNT(information2.serial),information2.employee_id from information2 join employee2 on employee2.id=information2.employee_id where employee2.contact=emp_con group by information2.employee_id;
	
end find_employee_servings; 


end myPackage; 
/