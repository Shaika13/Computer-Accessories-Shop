create or replace package myPackage as 

function find_prod(t in number)
   return SYS_REFCURSOR;
   
   --procedure available
	--(c OUT SYS_REFCURSOR);
	 procedure available
	(n in number,curs OUT SYS_REFCURSOR); 
	

    procedure find_employee
	(con in varchar,cur OUT SYS_REFCURSOR);
   	
   	
   	procedure find_employee_servings
	(emp_con in varchar,cur OUT SYS_REFCURSOR);
   	

end myPackage;
/